# Terminal_Application

## Referenced Material

Who wants to be a Millionaire?
## Link to Source Control Repo


## Code Styling / Styling Conventions

## Features

Idea: 
Basic concept is much like the TV show. A question is asked, four possible answers are generated and the user picks their answer. As the user progresses, the jackpot amount increases. Player can choose to end game with winnings after each round or continue. There is a time limit on each question and if the player answers incorrectly or the timer reaches 0, the game is over. 

Features:
A name input for the player to personalise the experience.
Require user input for answer responses that are timed.
A range of questions picked at random for individual playthroughs (we don’t want the user to just know all the answers in order)
Answers to change order for each playthrough.
A timer function to encourages quick player decisions.
Keep track of player progress, resets at New Game. - Will redo based on educator suggestions

## Implentation Plan

### How each feature will be implemented, prioritise and provide time indicator - checklist of tasks for each

## Help Documentation

### How to install
./run.sh will run the file on Mac
### Dependencies
As this is a Python-based terminal application, it will require the latest version of Python3 to be installed before it can run.
The following Python packages should be installed before running this code:
- art
- ascii-magic
- colorama
- colored
- iniconfig
- packaging
- Pillow
- pluggy
- pytest
### System / Hardware Requirements
The terminal application will run on most operating systems.
It is recommended that the terminal have 40 lines available as this will look best for the display of this app. 
This can be achieved using ```tput lines``` which will measure out the height of the terminal.
As this Terminal Application was created with a dark theme, it would be best displayed that way.
### How to Play







